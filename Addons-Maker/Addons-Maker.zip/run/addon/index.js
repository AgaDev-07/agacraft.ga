//require('../src/js/chisel')
const { input, dir } = require('../../library');
let STOP = false;

let array = [];
(async () => {
  await dir(__dirname, file => array.push(file.split('.js')[0]));

  while (!STOP) {
    let test = input(`Cual quieres ejecutar/`, { mark: '?', Default: array.text });
    STOP = /^([Ss][Tt][Oo][Pp])?([Ee][Xx][Ii][Tt])?$/.test(test);
    try {
      await require(`${__dirname}/${test}.js`)();
    } catch (e) {
      if (!STOP) console.log(e)
    }
  }
})();
