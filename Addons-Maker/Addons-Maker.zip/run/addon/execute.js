const getParam = require('../../library/aga/getParam');
(async () => {
  await require(`./${getParam('--read')}`)()
  console.log('\n\n-------------------------\n\n')
})()