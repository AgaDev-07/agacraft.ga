const item = require('../../src/data/item.json');
module['exports'] = async (id=item.id, name=item.name, material=item.material) => {
  const RP = await require('../../src/script/Resource');
  const BP = await require('../../src/script/Behavior');

  let config = {
    id,
    name,
    config: {
      type: 'armor',
      armor: item.config.armor
    },
  }

  new BP.Item().read(config);
  BP.Recipe.Default.Armor({ material, id }).createFile()

  new RP.Item().read(config);
};
