const item = require('../../src/data/item.json');
module['exports'] = async (id = item.id, name = item.name, material = item.config.material, stick = item.config.tools.stick) => {
  const RP = await require('../../src/script/Resource');
  const BP = await require('../../src/script/Behavior');

  let config = {
    id,
    name,
    config: {
      type: 'tools',
      tools: item.config.tools,
    },
  };

  new BP.Item().read(config);
  BP.Recipe.Default.Tools({ stick, material, id }).createFile();

  new RP.Item().read(config);
};
