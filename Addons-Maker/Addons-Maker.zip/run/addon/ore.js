module['exports'] = async () => {
  const BP = await require('../../src/script/Behavior');
  const RP = await require('../../src/script/Resource');
  const ore = require('../../src/data/ore.json');

  let blockBP = new BP.Block();
  await blockBP
    .read({
      id: ore.id,
      tag: 'stone',
      lvl: ore.blocks.ore.pickaxe,
      name: `${ore.name}_ore`,
      type: 'ore',
      color: ore.blocks.ore.color,
      is_stone: true,
      destroy_time: 10,
      item: ore.is_ingot ? `${ore.id}:raw_${ore.name}` : `${ore.id}:${ore.name}`,
      itemCount: ore.blocks.ore.item,
    }).then(block => block.createFile())
  await blockBP
    .read({
      id: ore.id,
      tag: 'stone',
      lvl: ore.blocks.block.pickaxe,
      name: `${ore.name}_block`,
      type: 'Construction',
      color: ore.blocks.block.color,
      is_stone: true,
      destroy_time: 10,
    }).then(block => block.createFile());

  let blockRP = new RP.Block();
  await blockRP.read({
    id: ore.id,
    name: `${ore.name}_ore`,
    sound: 'stone',
    is_table: false,
    folder: false,
    type: 'ore',
  });
  await blockRP.read({
    id: ore.id,
    name: `${ore.name}_block`,
    sound: ore.blocks.block.sound,
    is_table: false,
    folder: false,
  });
  if (ore.is_ingot) {
    await blockBP
      .read({
        id: ore.id,
        tag: 'stone',
        lvl: ore.blocks.block.pickaxe,
        name: `raw_${ore.name}_block`,
        type: 'Construction',
        color: ore.blocks.block.color,
        is_stone: true,
        destroy_time: 10,
      }).then(block => block.createFile());
    await blockRP.read({
      id: ore.id,
      name: `raw_${ore.name}_block`,
      sound: ore.blocks.block.sound,
      is_table: false,
      folder: false,
      type: 'raw',
    });
  }

  let material = ore.is_ingot ? `${ore.id}:${ore.name}_ingot` : `${ore.id}:${ore.name}`;

  await require('./item')(ore.id, ore.name, ore.is_ingot ? 'ingot' : 'item');

  await require('./armor')(ore.id, ore.name, material);
  await require('./tools')(ore.id, ore.name, material);
};
