const item = require('../../src/data/item.json');
module['exports'] = async (id = item.id, name = item.name, type='item') => {
  const RP = await require('../../src/script/Resource');
  const BP = await require('../../src/script/Behavior');
  type.log
  type = type == 'ingot' ? type : 'item'
  type.log

  let config = {
    id,
    name,
    config:{type}
  }

  new BP.Item().read(config)

  new RP.Item().read(config);
}