const Zip = require('../library/zip');
require('../library/Extension/String');
const { mkdir, readFile } = require('fs');
const { name, project, description } = require('../src/data/addon.json');
const folderAddon = `${__dirname}/../${project}/${name}`;

const folder = project.test(/^([a-z]:)/i) ? project : `${__dirname}/../../${project}`;

MANIFEST(() =>
  'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (count) {
    let Time = new Date().getTime();
    let random = (Time + Math.random() * 16) % 16 | 0;
    return (count === 'x' ? random : (random & 0x3) | 0x8).toString(16);
  })
);

mkdir(`${__dirname}/../addons/`, () => {
  new Zip(`${__dirname}/../addons/${name}.mcaddon`)
    .folder(`${folderAddon}_RP`)
    .folder(`${folderAddon}_BP`)
    .finalize();
});

function MANIFEST(uuid) {
  let manifest = (uuid => ({
    BP: {
      format_version: 2,
      header: {
        name: name,
        description: description,
        uuid: uuid[0],
        version: [1, 0, 0],
        min_engine_version: [1, 13, 0],
      },
      modules: [
        {
          type: 'data',
          uuid: uuid[1],
          version: [1, 0, 0],
        },
      ],
      dependencies: [
        {
          version: [1, 0, 0],
          uuid: uuid[2],
        },
      ],
    },
    RP: {
      format_version: 2,
      header: {
        name: name,
        description: description,
        uuid: uuid[2],
        version: [1, 0, 0],
        min_engine_version: [1, 13, 0],
      },
      modules: [
        {
          type: 'resources',
          uuid: uuid[3],
          version: [1, 0, 0],
        },
      ],
    },
  }))([uuid(), uuid(), uuid(), uuid()]);

  let toJson = obj => {
    let folders = `${folder}/${name}_${obj}`;
    readFile(`${__dirname}/../${folders}/manifest.json`, err => {
      if (err) JSON.stringify(manifest[obj], null, 2).createFile(folders + '/manifest.json');
    });
  };
  toJson('RP');
  toJson('BP');
}
