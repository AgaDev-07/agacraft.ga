const { copyObject } = require('../library');

function BP() {
  return true;
}
function RP() {
  return true;
}
function Add(json) {
  return json.toJson();
}

BP.Data = async (Class, {args, callback}, combineA, combineB) => {
  combineB = combineB || combineA;
  await combineA.forEach(async valueA =>
    await combineB.forEach(async valueB => {
      let Args = copyObject(args)
      Args.name = valueA === valueB ? valueA : valueA + valueB;
      await Class(Args, callback)
    })
  );
};
module['exports'] = { BP, RP, Add };

