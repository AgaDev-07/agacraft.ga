'use strict';
/**
 * @param {string} name
 * @param {function} func
 */
 let addProperty = function (name, func) {
  Function.prototype.__defineGetter__(name, func);
};

/**
 * @param {string} name
 * @param {function} func
 */
let addFunction = function (name, func) {
  Function.prototype[name] = func;
};

addFunction('watch', function () {
  console.log(this.toString())
  return this
})
addFunction('response', function (...args) {
  let res = this(...args)
  console.log(res)
  return res
})

module['exports'] = {
  addProperty,
  addFunction
};