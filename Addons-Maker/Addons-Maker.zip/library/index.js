module['exports'] = {
  ...require('./aga'),
  ...require('./extension'),
};