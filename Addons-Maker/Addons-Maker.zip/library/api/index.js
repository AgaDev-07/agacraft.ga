const { getRandomNumber } = require('..');
const { names, World } = require('./data.json');
function getName(sex) {
  sex = sex || getRandomNumber().round() ? 'feminine' : 'male';
  let name = getRandomNumber().round()
    ? [names.name[sex][getRandomNumber(0, names.name[sex].length - 1).round()]]
    : [
        names.name[sex][getRandomNumber(0, names.name[sex].length - 1).round()],
        names.name[sex][getRandomNumber(0, names.name[sex].length - 1).round()],
      ];
  name = name[0] === name[1] ? name[0] : `${name[0]} ${name[1] || ''} `.replace('  ', ' ');
  let lastNames = `${names.lastName[getRandomNumber(0, names.lastName.length - 1).round()]} ${
    names.lastName[getRandomNumber(0, names.lastName.length - 1).round()]
  }`;

  return name + lastNames;
}
module['exports'] = { getName };
