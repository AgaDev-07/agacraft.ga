module['exports'] = function (animation, text = '') {
  animation ||= ['.  ', '.. ', '...'];
  let n = 0,
    off = false,
    end;
  let interval = setInterval(() => {
    n = n >= animation.length ? 0 : n;
    process.stdout.write(text + animation[n] + '\r');
    n++;
    if (off) {
      clearInterval(interval);
      console.log(end);
    }
  }, 500);
  return {
    end: (text = '') => {
      off = true;
      end = text;
    },
  };
};
