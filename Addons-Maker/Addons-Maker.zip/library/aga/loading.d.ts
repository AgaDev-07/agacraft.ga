declare function loading(
  animation: String[] | ['.  ', '.. ', '...'] | ['| ', '/ ', '--', '\\'],
  text: String | 'Loading'
): {
  end: (text: String) => void;
};

export default loading;
