///library
const { newFolder } = require('../../library');
///JSON
const { name, project } = (addon = require('../data/addon.json'));

///Data
const folder = project.test(/^([a-z]:)/i) ? project : `${__dirname}/../../${project}`,
  RP = `${folder}/${name}_RP`,
  BP = `${folder}/${name}_BP`,
  textures = '/textures',
  atta = '/attachables',
  text = '/texts',
  model = '/models',
  block = '/blocks',
  item = '/items',
  armor = '/armor',
  loot = '/loot_tables',
  recipe = '/recipes',
  feature_rule = '/feature_rules',
  feature = '/features';

let Project = () =>{
  return folder.split('/').map((value, index, array) => {
    let valueFinal;
    if (index === 0)
      if (value == '.') valueFinal = __dirname;
      else valueFinal = `${__dirname}/${value}`;
    else {
      valueFinal = previous(index, array);
      if (value !== '..') newFolder(valueFinal);
    }
    return valueFinal;
  }).endItem;
  function previous(index, array) {
    if (index == 0) return array[index]
    return previous(index-1, array)+'/'+array[index]
  }
}

let Behavior = async () => {
  Project();
  let returns = newFolder(BP);
  return returns;
};
Behavior.blocks = async name =>
  newFolder(`${newFolder(`${await Behavior()}${block}`)}/${name || ''}`);
Behavior.item = async () => newFolder(`${await Behavior()}/${item}`);
Behavior.loot = async name =>
  newFolder(`${newFolder(`${await Behavior()}/${loot}`)}/${name || ''}`);
Behavior.recipe = async name =>
  newFolder(`${newFolder(`${await Behavior()}/${recipe}`)}/${name || ''}`);

Behavior.feature = async () => {
  await Behavior();
  newFolder(feature);
  return newFolder(feature_rule);
};

let Resource = async () => {
  Project();
  let returns = newFolder(RP);
  return returns;
};
Resource.attachables = async () => newFolder(`${await Resource()}/${atta}`);
Resource.texts = async () => newFolder(`${await Resource()}/${text}`);
Resource.textures = async () => newFolder(`${await Resource()}/${textures}`);
Resource.textures.items = async () => newFolder(`${await Resource.textures()}/${item}`);
Resource.textures.models = async () => newFolder(`${await Resource.textures()}/${model}`);
Resource.textures.models.armor = async () =>
  newFolder(`${await Resource.textures.models()}/${armor}`);
Resource.textures.blocks = async name =>
  newFolder(`${newFolder(`${await Resource.textures()}/${block}`)}/${name || ''}`);

Project.Behavior = Behavior;
Project.Resource = Resource;
Project.Folder = folder;

module.exports = Project;
