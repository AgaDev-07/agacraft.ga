///Libraries
const Plugin = require('../plugin');
const Project = require('../folders');
const lib = require('./index.lib');
const { Speak } = require('../lib');
const aga = require('../../../library');

///JSON constant's
const addon = require('../../data/addon.json');
const ore = require('../../data/ore.json');

///JSON variables
let blocksJson;
let item_textureJson;
let terrain_textureJson;

async function valorJson() {
  let { blocks, item_texture, terrain_texture } = lib.valor();
  blocksJson = blocks;
  item_textureJson = item_texture;
  terrain_textureJson = terrain_texture;
}
class Block{
  async read({ id, name, sound, is_table, type, folder, extend }) {
    this.id = id || 'aga';
    this.name = name || 'material';
    this.sound = sound || 'stone';
    this.is_table = is_table || false;
    this.folder = folder || false;
    await valorJson();
    await Project.Resource.textures.blocks(this.folder ? '' : this.name);
    await lib.is_table(
      this.is_table,
      { blocksJson, terrain_textureJson },
      { id: this.id, name: this.name, sound: this.sound, type }
    );
    let returns = Speak({ name: 'RP', type:'Blocks', message: `${this.id}:${this.name} complete!!` });
    returns.Plugin = async callback => (await new Plugin({ carp: 'RP', type: ['Blocks', 'Translate'], extend })).load(callback)
    return returns;
  }
}

class Item {
  async read({ id, name, type, config, extend }) {
    this.id = id || 'aga';
    this.name = name || 'material';
    this.type = config.type || type || 'item';
    extend = extend || {}
    extend.language = extend.language || 'item';
    await Project.Resource.textures.items();
    await valorJson();

    let texture = '';
    try {
      texture = await lib.type[this.type.toLowerCase()](item_textureJson, {
        id: this.id,
        name: this.name,
        type: this.type,
      });
    } catch (_) {
      _.log
      texture = await lib.type.item(item_textureJson, {
        id: this.id,
        name: this.name,
        type: this.type,
      });
    }

    let returns = Speak({ name: 'RP', type: 'Items', message: `${this.id}:${this.name} complete!!` });
    returns.Plugin = async callback => (await new Plugin({ carp: 'RP', type: ['Items', 'Translate'], extend })).load(callback);
    return returns;
  }
}

aga.newFolder(`${aga.newFolder(`${__dirname}/../../../${addon.project}`)}/${addon.name}_RP`)
module['exports'] = (async () => await Plugin.Add('rp', { Block, Item }))();
