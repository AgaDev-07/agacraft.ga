/**
 * Create Texture Blocks
 */
export class Block {
  read(config: {
    id: String;
    name: String;
    sound: String;
    is_table: Boolean;
    folder: Boolean;
  }): String;
}
/**
 * Create Texture Items
 */
export class Item {
  read(config: { id: String; name: String; type: String; extend: Object }): String;
}
