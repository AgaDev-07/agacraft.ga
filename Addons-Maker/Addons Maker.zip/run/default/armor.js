module['exports'] = async () => {
  const RP = await require('../../src/script/Resource');
  const BP = await require('../../src/script/Behavior');

  new BP.Item().read({
    id: 'aga',
    name: 'material',
    config: {
      type: 'armor',
      armor: {
        helmet: { durability: 816, armor: 4 },
        chestplate: { durability: 1108, armor: 6 },
        leggings: { durability: 1108, armor: 5 },
        boots: { durability: 960, armor: 3 },
      },
    },
  })

  new RP.Item().read({ id: 'aga', name: 'material', type: 'armor' });
};
