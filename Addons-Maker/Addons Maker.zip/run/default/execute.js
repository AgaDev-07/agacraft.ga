const getParam = require('../../library/aga/getParam');
(async () => {
  let param = getParam('--read');
  await require(`./${param}`)()
})();