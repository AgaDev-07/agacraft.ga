//global interfaces
declare global {
  interface String {
    replaceFull(replaces: String[], sign?: String): String;
    startAndEnd(start: string, end?: string): Boolean;
    dataExists(data: string): Boolean;
    createFile(path: string): String;
    writeFile(path: string): String;
    toBoolean(): Boolean;
    toObject(): Object;
    error: String;
    info: String;
    warn: String;
    log: String;
  }
  interface Buffer {
    createFile(path: string): Buffer;
    writeFile(path: string): Buffer;
    log: Buffer;
  }
  interface Object {
    compare(Obj: Object): Boolean;
    toJson(): String;
    keys: {
      (): String[];
      inverse(): Object;
    };
    log: Object;
  }
  interface Array<T> {
    deleteIndex(index: Number | Number[]): T[];
    getData(spaces: Number | Number[]): T[];
    dataExists(data: any): Boolean;
    compare(Arr: T[]): Boolean;
    max(maximum: Number): T[];
    order: {
      (): T[];
      number(): Number[];
      string(): string[];
    };
    log: T[];
    text: String;
  }
  interface Boolean {
    txt: String;
    log: Boolean;
  }
  interface Function {
    watch(): String;
  }
  interface Number {
    raised(raised: Number): Number;
    root(root: Number): Number;
    round(): Number;
    txt: String;
    log: Number;
  }
}
export const addProperty = {
  array(name: String, callback: Function): void;,
  buffer(name: String, callback: Function): void;,
  object(name: String, callback: Function): void;,
  string(name: String, callback: Function): void;,
  number(name: String, callback: Function): void;,
  boolean(name: String, callback: Function): void;,
  function(name: String, callback: Function): void;,
};

export const addFunction = addProperty;