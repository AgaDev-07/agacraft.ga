'use strict';
const { readFileSync, writeFile } = require('fs');
/**
 * @param {string} name
 * @param {function} func
 */
let addProperty = function (name, func) {
  Buffer.prototype.__defineGetter__(name, func);
};

/**
 * @param {string} name
 * @param {function} func
 */
let addFunction = function (name, func) {
  Buffer.prototype[name] = func;
};
addProperty('log', function(){
  console.log(this)
  return this
})
addFunction('createFile', function (path = './text.txt') {
  writeFile(path, this, err => {
    if (err) err.log
  });
  return this;
});
addFunction('writeFile', async function (path) {
  let data;
  try {
    data = await readFileSync(path);
  } catch (error) {
    data = '';
  }
  data += this;
  return Buffer.from(data).createFile(path);
});

module['exports'] = {
  addProperty,
  addFunction
};