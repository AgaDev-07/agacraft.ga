declare global {
  interface String {
    black: string;
    red: string;
    green: string;
    yellow: string;
    blue: string;
    magenta: string;
    cyan: string;
    white: string;
    gray: string;
    grey: string;

    blackBg: string;
    redBg: string;
    greenBg: string;
    yellowBg: string;
    blueBg: string;
    magentaBg: string;
    cyanBg: string;
    whiteBg: string;

    blackBright: string;
    redBright: string;
    greenBright: string;
    yellowBright: string;
    blueBright: string;
    magentaBright: string;
    cyanBright: string;
    whiteBright: string;
    grayBright: string;
    greyBright: string;

    blackBrightBg: string;
    redBrightBg: string;
    greenBrightBg: string;
    yellowBrightBg: string;
    blueBrightBg: string;
    magentaBrightBg: string;
    cyanBrightBg: string;
    whiteBrightBg: string;

    bold: string;
    inverse: string;
    clear: string;
  }
}

export function copyObject(object: Object): Object;
export function copyArray(array: T[]): T[];
export function generateUUID(): String;
export function type(data: any): String;
export function isArray(data: any): Boolean;
export function isString(data: any): Boolean;
export function isObject(data: any): Boolean;
export function isNumber(data: any): Boolean;
export function isBoolean(data: any): Boolean;
export function isIterable(data: any): Boolean;
export function exists(path: String): Boolean;
export function readFile(path: String): Buffer;
export function newFolder(route: String): String;
export function requireJson(path: String): Object;
export function copyFile(copy: String, paste: String): void;
export function dir(route: String, callback: (file: String) => void): void;
export function array(array: any[], callback: (file: String) => void): void;
export function newExtension(
  config: { path: String; extension: String },
  callback: (data: { name: String; file: Object }) => void
): void;
export function getParam(param: String): String | Boolean | Number;
export function isFile(path: String): Boolean;
export function isFolder(path: String): Boolean;
export function exists(path: String): Boolean;

export function input(
  ask?: String,
  value?: String,
  opts?: { autocomplete?: (str: String) => String[]; echo?: String }
): String;

export function input(
  ask?: String,
  opts?: { autocomplete?: (str: String) => String[]; echo?: String; value?: String }
): String;

export function input(opts?: {
  autocomplete?: (str: String) => String[];
  echo?: String;
  value?: String;
  ask?: String;
}): String;
