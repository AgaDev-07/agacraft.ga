from tkinter import Tk, Label, Button, Toplevel
from os import system


class Window:
    def __init__(self, title, icon, window=Tk()):
        self.window = window
        self.title = title
        self.icon = icon

        self.window.title(self.title)
        self.window.config(background='black')
        self.window.iconbitmap(self.icon)

        screen = Label(self.window, text=self.title, width=40,
                        height=3, bg='black', fg='#00ffff', font=('Helvetica', 15))
        screen.grid(row=0, column=0, columnspan=4, padx=5, pady=5)

        self.sub_window_config = {}
        self.sub_window = {}
        self.buttons = []
        self.types= {}

    def run(self):
        self.order_buttons(self.buttons)
        self.window.mainloop()

    def create_button(self, text, id=None, type='run', window=None, buttons=None):
        if window == None:
            window = self.window
        if buttons == None:
            buttons = self.buttons
        buttons.insert(buttons.__len__(), self.button(text, window, type, id))

    def order_buttons(self, buttons):
        index_button = 0
        for row in range(1, 4):
            for column in range(4):
                if(index_button < buttons.__len__()):
                    buttons[index_button].grid(row=row, column=column)
                    index_button += 1

    def button(self, text, window, type, id=None):
        if(id == None):
            id = text
        button = Button(window, text=text, width=9, height=1, font=('Helvetica', 15),
                        command=lambda: self.click(id, type),
                        background='#00ffff', foreground='black')
        return button

    def click(self, id, type):
        try: self.types[type](id)
        except:None

    def set_type(self, type, function):
        self.types[type] = function

    def new_window(self, name):
        self.sub_window[name] = Window(f'{self.title} ({name})', self.icon, Toplevel())
        self.get_sub_window_config(name)
        self.sub_window[name].run()

    def get_sub_window_config(self, name):
        try: self.sub_window_config[name](self.sub_window[name])
        except:None

    def set_sub_window_config(self, name, function): self.sub_window_config[name] = function

def run():
    main = Window('Addons Maker', f'./aga.ico')

    main.create_button('armor')
    main.create_button('block')
    main.create_button('item')
    main.create_button('ore')
    main.create_button('tools')
    main.create_button('config', type='open')

    main.set_type('run', lambda id: system(f'cd ./run/default & node execute --read="{id}"'))
    main.set_type('open', lambda id: main.new_window(id))

    main.set_sub_window_config('config', config)

    main.run()

def config(window):
    window.create_button('addon')
    window.create_button('block')
    window.create_button('item')
    window.create_button('ore')
    window.create_button('pickaxe')
    window.create_button('plugins')
    window.order_buttons(window.buttons)

    window.set_type('run', lambda id: system(f'cd ./src/data & start {id}.json'))

if __name__ == '__main__': run()
