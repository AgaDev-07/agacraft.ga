require('./library');

let a = [0, 1, 2];
let b = [0, 1, 2];

console.log(a.compare(b));
