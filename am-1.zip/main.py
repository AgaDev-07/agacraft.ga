from tkinter import Tk, Label, Button, Toplevel
from os import system


class Gui:
    def __init__(self, window):
        self.window = window
        self.window.title('Addons Maker')
        self.window.config(background='black')

        screen = Label(self.window, text='Addons Maker Gui', width=40,
                            height=3, bg='black', fg='#00ffff', font=('Helvetica', 15))
        screen.grid(row=0, column=0, columnspan=4, padx=5, pady=5)

        self.buttons = []
        self.create_button('Block', id='block')
        self.create_button('Item', id='item')
        self.create_button('Tools', id='tools')
        self.create_button('Armor', id='armor')
        self.create_button('Ore', id='ore')
        self.create_button('Config', id='config')
        self.open_config = False
        index_button = 0
        for row in [1, 2]:
            for column in range(4):
                if(index_button < self.buttons.__len__()):
                    self.buttons[index_button].grid(row=row, column=column)
                    index_button += 1

    def create_button(self, text, id):
        self.buttons.insert(self.buttons.__len__(), self.button(
            text=text, id=id, window=self.window))

    def config_button(self, text, id):
        self.config_buttons.insert(self.buttons.__len__(), self.button(
            text=text, id=id, type='config', window=self.config))

    def button(self, text='', id='', type='button', window=''):
        if(id == ''):
            id = text
        button = Button(window, text=text, width=9, height=1, font=('Helvetica', 15),
                        command=lambda: self.click(id=id, type=type),
                        background='#00ffff', foreground='black')
        return button

    def click(self, id, type):
        if id=='config':
            if self.open_config:
                self.config.destroy()
                self.open_config =False
            else:
                self.config_widow()
        elif type == 'config':
            system(f'start src/data/{id}.json')
        else:
            system(f'node run/default/{id}')
    def config_widow(self):
        self.config=Toplevel()
        self.config.title('Addons Maker (Config)')
        self.config.config(background='black')

        screen = Label(self.config, text='Config', width=40,
                            height=3, bg='black', fg='#00ffff', font=('Helvetica', 15))
        screen.grid(row=0, column=0, columnspan=4, padx=5, pady=5)
        
        self.config_buttons = []
        self.config_button('Addon', id='addon')
        self.config_button('Block', id='block')
        self.config_button('Item', id='item')
        self.config_button('Ore', id='ore')
        self.config_button('Pickaxe', id='pickaxe')
        self.config_button('Plugins', id='plugins')
        index_button = 0
        for row in [3, 4]:
            for column in range(4):
                if(index_button < self.config_buttons.__len__()):
                    self.config_buttons[index_button].grid(row=row, column=column)
                    index_button += 1
        self.open_config =True


index_window = Tk()

Gui(index_window)

index_window.mainloop()
