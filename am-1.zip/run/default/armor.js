module['exports'] = async () => {
  const RP = require('../../src/script/Resource')
  const BP = require('../../src/script/Behavior')

  let ItemBP = new BP.Item();
  ItemBP.read()
}